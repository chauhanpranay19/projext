'use strict';



/**
 * navbar toggle
 */

const navOpenBtn = document.querySelector("[data-nav-open-btn]");
const navbar = document.querySelector("[data-navbar]");
const navCloseBtn = document.querySelector("[data-nav-close-btn]");

const navElemArr = [navOpenBtn, navCloseBtn];

for (let i = 0; i < navElemArr.length; i++) {
  navElemArr[i].addEventListener("click", function () {
    navbar.classList.toggle("active");
  });
}

/**
 * toggle navbar when click any navbar link
 */

const navbarLinks = document.querySelectorAll("[data-nav-link]");

for (let i = 0; i < navbarLinks.length; i++) {
  navbarLinks[i].addEventListener("click", function () {
    navbar.classList.remove("active");
  });
}

const tabButtons = document.querySelectorAll('.tab-btn');
const tabContent = document.querySelectorAll('.tab-content div');

tabButtons.forEach(button => {
  button.addEventListener('mouseover', () => {
    const contentToShow = button.getAttribute('data-content');
    
    // Hide all tab content
    tabContent.forEach(content => {
      content.classList.remove('active');
    });
    
    // Show the corresponding tab content
    const selectedContent = document.querySelector(`[data-tab="${contentToShow}"]`);
    selectedContent.classList.add('active');
  });
});
var marker = L.marker([18.5204, 73.8567]).addTo(map);
marker.bindPopup("Pune, India").openPopup();


/**
 * header active when window scrolled down
 */

const header = document.querySelector("[data-header]");

window.addEventListener("scroll", function () {
  window.scrollY >= 50 ? header.classList.add("active")
    : header.classList.remove("active");
});

